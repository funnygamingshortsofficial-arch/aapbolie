# AapBolie — Android AI Voice Assistant

यह प्रोजेक्ट Android Studio / GitHub Actions से Debug APK बनाने के लिए है।

## इस अपडेट में
- Live voice loop: जवाब बोलने के बाद अगली सुनने की बारी अपने-आप शुरू होती है; Stop के लिए मुख्य माइक बटन दबाएँ।
- Live स्क्रीन पर Online Voice और Offline Voice के अलग चयन। Offline चयन Android on-device SpeechRecognizer को प्राथमिकता देता है। इसकी उपलब्धता फोन और डाउनलोड किए गए भाषा पैक पर निर्भर है।
- Accessibility सेवा की वास्तविक enabled-state जाँच, बेहतर हिंदी/अंग्रेज़ी ऐप खोलने के नियम, editable field में टाइप और Send बटन पहचान।
- Overlay अनुमति के साथ वैकल्पिक Dynamic-Island-जैसा status pill; Settings में चालू/बंद।
- MediaPipe `.task` मॉडल इम्पोर्ट, फ़ाइल-साइज़ जाँच और संगत मॉडल की आधिकारिक Android गाइड।
- GitHub Actions workflow APK बनाकर artifact अपलोड करता है।

## जरूरी सीमाएँ
1. ऐप में कोई AI API key शामिल नहीं है। अपनी API key Settings में डालें। APK में किसी डेवलपर की स्थायी secret key रखना सुरक्षित नहीं होता; APK से निकाली जा सकती है।
2. Offline LLM तभी चलेगा जब MediaPipe LLM Inference के अनुकूल `.task` मॉडल फोन में इम्पोर्ट किया गया हो। साधारण GGUF फाइल सीधे समर्थित नहीं है। मॉडल डाउनलोड बड़ा हो सकता है और RAM/स्टोरेज/डिवाइस सपोर्ट जरूरी है।
3. Offline Speech Recognition Android के सिस्टम speech service और डाउनलोड किए गए भाषा पैक पर निर्भर है। हर Samsung/Android build में सभी भाषाओं के लिए offline pack उपलब्ध नहीं होता।
4. Overlay pill एक छोटा status indicator है, पूर्ण iOS Dynamic Island clone नहीं। Android की Overlay अनुमति आवश्यक है।
5. Accessibility automation केवल स्क्रीन पर उपलब्ध और सुलभ UI तत्वों पर काम करती है। हर ऐप के हर बटन/सुरक्षित स्क्रीन को नियंत्रित करने की गारंटी नहीं है। भुगतान/लॉगिन/सुरक्षा चरणों में यूज़र को खुद काम करना होगा।
6. “24/7 free” की गारंटी नहीं: फोन, बैटरी, Android background limits, मॉडल memory और third-party API की शर्तें लागू होती हैं।

## GitHub से APK
1. इस ZIP को extract करके इसकी अंदर की सभी फाइलें GitHub repository के root में upload करें (यानी `AapBolie/` के अंदर की फाइलें root में हों)।
2. GitHub → Actions → **Android APK** workflow चुनें → **Run workflow**।
3. सफल build के बाद workflow run के Artifacts में `AapBolie-debug-apk` डाउनलोड करें।

## स्थानीय Build
Android Studio में प्रोजेक्ट खोलें और `assembleDebug` चलाएँ। आवश्यक SDK: Android 34, JDK 17, Gradle 8.7।
