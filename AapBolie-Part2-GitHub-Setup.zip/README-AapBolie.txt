# AapBolie Android project

## Build with GitHub Actions
1. Upload the two ZIP files to the repository root.
2. Put this workflow at `.github/workflows/build.yml` (the second ZIP contains it).
3. Run Actions → Build APK → Run workflow.
4. Download the `AapBolie-APK` artifact after a successful run.

## Offline voice error 13
Android SpeechRecognizer error 13 means `ERROR_LANGUAGE_UNAVAILABLE`: the requested language pack is not available to the on-device recognizer. Install the matching offline speech language in Android/Speech Services settings. The app now selects Android's on-device recognizer for offline mode on Android 12+ and displays a Hindi explanation for error 13. Availability of Hindi/Marathi offline packs depends on the phone's installed speech service.

This patch fixes error reporting and on-device recognizer selection; it does not bundle a speech model inside the APK.
