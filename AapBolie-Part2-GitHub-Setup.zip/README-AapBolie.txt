AAPBOLIE — GITHUB BUILD SETUP (UPDATED FOR LITERT-LM)

KEEP THESE EXACT ZIP NAMES:
1) AapBolie-Part1-Source-Code.zip
2) AapBolie-Part2-GitHub-Setup.zip

STEPS:
1. Upload both ZIP files to the root of the same GitHub repository.
2. Extract this setup ZIP on your phone.
3. Add its .github/workflows/build.yml file to the repository at exactly .github/workflows/build.yml.
4. Open GitHub → Actions → Build APK → Run workflow.
5. After a successful run, download the AapBolie-APK artifact.

The workflow uses Java 17 and Gradle 8.9. The source project uses AGP 8.5.2, Kotlin 2.3.21, and LiteRT-LM Android 0.18.0. Kotlin 2.3.21 is intentional: LiteRT-LM 0.18.0 requires Kotlin 2.3 or newer.

WHAT THE UPDATED SOURCE INCLUDES:
- LiteRT-LM runtime instead of the old MediaPipe .task runtime.
- In-app Gemma 3 1B INT4 download after user confirmation, progress display, free-space check, SHA-256 verification and app-private storage. No browser page should open.
- Multi-turn conversation context for cloud providers and a persistent LiteRT-LM conversation for offline Gemma.
- Continuous voice loop re-listens after the spoken answer; no-speech timeouts retry.
- Online APIs, text input, speech-to-text, text-to-speech and optional Accessibility-based phone commands.

BUILD STATUS:
The ZIPs are checked for archive integrity. This environment does not have Android SDK/Gradle installed, so an APK compile has NOT been verified here. GitHub Actions must complete successfully before installing the APK. If Actions reports an error, share the first red error section for correction.
