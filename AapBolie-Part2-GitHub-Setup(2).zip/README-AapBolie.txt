AAPBOLIE — UPDATED MOBILE BUILD PACKAGE

ZIP FILE NAMES (KEEP THESE EXACTLY):
1) AapBolie-Part1-Source-Code.zip
2) AapBolie-Part2-GitHub-Setup.zip

IMPORTANT GITHUB SETUP:
- Upload BOTH ZIP files to the repository root (same repository).
- GitHub Actions will NOT discover a workflow that is only stored inside a ZIP archive.
- Extract this setup ZIP on your phone and add its .github/workflows/build.yml file to the repository at exactly:
  .github/workflows/build.yml
- After that, open GitHub -> Actions -> Build APK -> Run workflow.
- On a push, the workflow extracts the two ZIP files and builds the debug APK.
- After a successful run, download the AapBolie-APK artifact.

VOICE FIXES:
- Online speech error 17 is not a standard Android SpeechRecognizer error code. On Android 12+ the app now tries the on-device recognizer once as a fallback when that vendor/service returns 17.
- If fallback is unavailable, the app shows a diagnostic message to update/check the phone's speech recognition service and microphone permission.
- Offline error 13 is still explained as a missing/unavailable on-device language pack.

UI FIXES:
- Live screen now has separate Online and Offline voice buttons.
- Conversation area is scrollable on small phone screens.
- Settings choice chips wrap to multiple rows instead of being cut off at the screen edge.
- Offline model section has a model-page button and a separate import button.

OFFLINE MODEL NOTE:
- The current app runtime loads MediaPipe-compatible .task files.
- Gemma 3n E2B's current .litertlm download is NOT compatible with this older MediaPipe runtime as-is. Do not import a .litertlm file into the .task picker.
- The model page button opens Google's official documentation. Select a compatible .task model, download it yourself, then use "डाउनलोड की हुई .task फ़ाइल चुनें" inside the app.
- No large model is downloaded automatically. Confirm and check free storage/RAM before downloading.

BUILD STATUS:
- ZIP integrity and workflow filename references were checked.
- This environment does not have Gradle/Android SDK available, so an APK compile has NOT been verified here. GitHub Actions is the actual build check.
