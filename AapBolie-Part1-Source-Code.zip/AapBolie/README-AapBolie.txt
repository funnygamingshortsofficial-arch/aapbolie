AAPBOLIE — COMPLETE SOURCE (LiteRT-LM + Gemma)

What is included:
- Android Kotlin + Jetpack Compose app.
- Online providers: Gemini, Claude, OpenAI, Groq, OpenRouter, DeepSeek and custom OpenAI-compatible endpoint.
- Multi-turn cloud chat context (last 10 turns) when Memory is enabled; incognito disables it.
- Offline Gemma 3 1B INT4 using Google's LiteRT-LM Android runtime (CPU backend for compatibility).
- In-app model download with a consent dialog, progress, free-storage check, SHA-256 verification, app-private storage, and no browser redirect.
- Approximate model size: 557 MiB. Download is user-triggered only. The app requires internet for the first download; afterward the model can run offline.
- Voice input and TTS; continuous voice mode re-arms listening after the spoken answer and retries empty/no-speech timeouts.
- App automation via Android Accessibility Service remains optional and must be enabled by the user in Android Settings.

MODEL / LICENSE:
The bundled app does NOT contain the model. It downloads Gemma 3 1B INT4 in LiteRT-LM format after the user confirms. Gemma Terms of Use and prohibited-use policy apply. The model is downloaded from a public Hugging Face mirror and SHA-256 checked against the published digest before installation. Approximate file size 584,417,280 bytes.

BUILD:
- Android Gradle Plugin 8.5.2, Kotlin 2.3.21, Java 17, compileSdk 34, minSdk 26.
- LiteRT-LM dependency: com.google.ai.edge.litertlm:litertlm-android:0.18.0 (requires Kotlin 2.3+).
- Use GitHub Actions setup in Part 2. Place .github/workflows/build.yml in the repository root and upload the two ZIPs using their exact names.

IMPORTANT HONEST LIMITATIONS:
- This source was updated against Google's published LiteRT-LM Kotlin API. The current editing environment has no Android SDK/Gradle installation, so no APK build or Samsung Galaxy A15 device test could be run here. A successful GitHub Actions build is required to verify dependency/API compatibility.
- Performance depends on free RAM, thermals, and device runtime support. Gemma 1B INT4 is a reasonable starting model for an 8 GB phone, not a speed guarantee. CPU backend is selected for compatibility; it does not assume Samsung NPU support.
- Offline speech recognition and TTS language packs are Android system services and must be installed/enabled separately in phone settings.
