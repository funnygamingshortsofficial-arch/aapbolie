AapBolie — updated source package

This source update includes:
- Separate one-shot speech-to-text input, typed message send, and replay-last-answer text-to-speech controls.
- Continuous online/offline voice conversation remains available.
- Text-to-speech waits for Android TTS initialization before speaking and reports missing voice data / playback errors.
- Android SpeechRecognizer error 11 is identified as ERROR_SERVER_DISCONNECTED (speech service disconnect), not an offline LLM error.
- New Midnight AI neutral dark/light theme replaces the orange default.
- Model information dialog appears before opening documentation. It clearly warns that this app's current MediaPipe runtime accepts .task files and does not run LiteRT-LM .litertlm models.

Important offline-model limitation:
The current offline LLM implementation still uses MediaPipe tasks-genai / LlmInference and a model.task file. The LiteRT-LM documentation shown in the user's screenshot describes a different runtime. Do not download a .litertlm file for this build. Migrating to LiteRT-LM requires upgrading the Kotlin toolchain and replacing the model loading/conversation implementation; that migration is not included or compile-verified in this ZIP.

Speech error 11:
Android defines error 11 as ERROR_SERVER_DISCONNECTED. It means the speech recognition service disconnected. Update Android/Google speech components, check the downloaded offline language pack, restart the phone, and try Online mode if needed. The app now displays a specific explanation.

Build:
Use the existing GitHub Actions workflow instructions in Part 2. This environment does not have the Android SDK/Gradle build toolchain, so the APK has not been compiled or device-tested here. A successful GitHub Actions run is still required before installing the APK.
