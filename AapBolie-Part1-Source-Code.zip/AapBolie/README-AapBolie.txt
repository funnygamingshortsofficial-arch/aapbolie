AapBolie — updated source package

This source package includes:
- Separate one-shot speech-to-text input, typed message send, and replay-last-answer text-to-speech controls.
- Continuous online/offline voice conversation remains available.
- Text-to-speech waits for Android TTS initialization before speaking and reports missing voice data / playback errors.
- Android SpeechRecognizer error 11 is identified as ERROR_SERVER_DISCONNECTED (speech service disconnect), not an offline LLM error.
- New Midnight AI neutral dark/light theme replaces the orange default.
- Model information dialog appears before opening documentation. It clearly warns that this app's current MediaPipe runtime accepts .task files and does not run LiteRT-LM .litertlm models.

Important offline-model limitation:
The current offline LLM implementation still uses MediaPipe tasks-genai / LlmInference and a model.task file. It does not yet provide an in-app Gemma download manager, and it cannot run LiteRT-LM .litertlm files. A compatible .task model must be obtained separately and selected in the app. Do not assume a Gemma .litertlm download will work in this build. A full LiteRT-LM migration and automatic model download have not been implemented or compile-verified in this ZIP.

Speech error 11:
Android defines error 11 as ERROR_SERVER_DISCONNECTED. It means the speech recognition service disconnected. Update Android/Google speech components, check the downloaded offline language pack, restart the phone, and try Online mode if needed. The app now displays a specific explanation.

Build:
Use the existing GitHub Actions workflow instructions in Part 2. This environment does not have the Android SDK/Gradle build toolchain, so the APK has not been compiled or device-tested here. A successful GitHub Actions run is still required before installing the APK.
