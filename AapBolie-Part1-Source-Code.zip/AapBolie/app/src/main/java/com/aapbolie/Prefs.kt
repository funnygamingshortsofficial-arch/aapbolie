package com.aapbolie
import android.content.Context

class Prefs(c: Context) {
  private val sp = c.getSharedPreferences("s", 0)
  fun s(k: String, d: String = "") = sp.getString(k, d) ?: d
  fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
  fun f(k: String, d: Float) = sp.getFloat(k, d)
  fun put(k: String, v: Any) { sp.edit().also { when (v) { is String -> it.putString(k, v); is Boolean -> it.putBoolean(k, v); is Float -> it.putFloat(k, v) } }.apply() }
}
/** एक लाइन = एक सेटिंग। नया विकल्प जोड़ना हो तो बस यहाँ एक लाइन जोड़ें। */
sealed class Opt(val key: String, val title: String)
class Tog(k: String, t: String, val def: Boolean = false) : Opt(k, t)
class Sli(k: String, t: String, val def: Float, val lo: Float, val hi: Float) : Opt(k, t)
class Pick(k: String, t: String, val items: List<String>) : Opt(k, t)

val SECTIONS: List<Pair<String, List<Opt>>> = listOf(
  "🔊 आवाज़" to listOf(
    Pick("voice", "आवाज़ का मॉडल", listOf("Emma", "Aarav", "Rohan", "Ananya", "Kabir")),
    Sli("speed", "बोलने की गति", 1.0f, 0.5f, 2.0f), Sli("pitch", "पिच", 1.0f, 0.5f, 2.0f), Sli("vol", "वॉल्यूम", 0.8f, 0f, 1f),
    Tog("speak", "जवाब बोलकर सुनाओ", true), Tog("wake", "वेक-वर्ड (\"हे बोलिए\")"), Tog("beep", "सुनने की बीप", true),
    Tog("haptic", "वाइब्रेशन फीडबैक", true), Tog("noise", "शोर कम करो"), Tog("auto_stop", "चुप होने पर अपने आप रुको", true)),
  "🌐 भाषा" to listOf(
    Pick("ui_lang", "ऐप की भाषा", listOf("हिंदी", "English", "मराठी", "বাংলা", "ગુજરાતી", "தமிழ்", "తెలుగు")),
    Pick("speak_lang", "बोलने की भाषा", listOf("हिंदी", "English", "मराठी", "বাংলা", "ગુજરાતી")),
    Pick("target_lang", "अनुवाद की भाषा", listOf("English", "हिंदी", "मराठी", "বাংলা")),
    Tog("devanagari", "रोमन की जगह देवनागरी", true), Tog("auto_detect", "भाषा अपने आप पहचानो", true)),
  "🤖 AI व्यवहार" to listOf(
    Pick("mode", "मोड", listOf("Auto", "Online", "Offline")),
    Sli("temp", "रचनात्मकता (temperature)", 0.7f, 0f, 1.5f),
    Pick("reply_len", "जवाब की लंबाई", listOf("छोटा", "सामान्य", "विस्तृत")),
    Pick("tone", "लहजा", listOf("दोस्ताना", "औपचारिक", "सीधा")),
    Tog("memory", "मेरी बातें याद रखो", true), Tog("web", "ज़रूरत पर वेब सर्च"), Tog("fallback", "ऑनलाइन फेल हो तो ऑफलाइन चलाओ", true)),
  "📱 फोन कंट्रोल" to listOf(
    Tog("confirm", "हर एक्शन से पहले पूछो"), Tog("verify", "हर स्टेप के बाद स्क्रीन जाँचो", true),
    Sli("delay", "स्टेप के बीच देरी (सेकंड)", 0.7f, 0.2f, 3f), Sli("retries", "दोबारा कोशिशें", 4f, 1f, 10f),
    Tog("float", "फ्लोटिंग बबल"), Tog("root", "रूट मोड (उन्नत)"), Tog("block_pay", "पेमेंट ऐप्स ब्लॉक रखो", true), Tog("stop_shake", "फोन हिलाकर रोको", true)),
  "🔒 प्राइवेसी" to listOf(
    Tog("local_hist", "हिस्ट्री सिर्फ फोन में", true), Tog("no_screen", "स्क्रीन टेक्स्ट क्लाउड पर न भेजो", true),
    Tog("lock", "ऐप लॉक (बायोमेट्रिक)"), Tog("incognito", "गुप्त मोड"), Tog("auto_clear", "7 दिन बाद हिस्ट्री मिटाओ")),
  "🎨 रूप-रंग" to listOf(
    Pick("theme", "थीम", listOf("Midnight AI", "Sage Garden", "Plum Ink", "Rose Clay")),
    Pick("appearance", "लाइट / डार्क", listOf("सिस्टम जैसा", "लाइट", "डार्क")),
    Sli("font", "अक्षर का आकार", 1.0f, 0.8f, 1.5f), Tog("anim", "एनीमेशन", true), Tog("round", "गोल कोने", true)),
  "💾 ऑफलाइन" to listOf(
    Pick("off_model", "ऑफलाइन मॉडल", listOf("Gemma 2B", "Qwen 1.5B", "Qwen 3B")),
    Tog("off_stt", "ऑफलाइन आवाज़ पहचान", true), Tog("off_tts", "ऑफलाइन आवाज़", true), Tog("wifi_dl", "मॉडल सिर्फ वाई-फाई पर डाउनलोड", true),
    Tog("browser_save", "ब्राउज़र पेज ऑफलाइन सेव (जल्द)"))
)
