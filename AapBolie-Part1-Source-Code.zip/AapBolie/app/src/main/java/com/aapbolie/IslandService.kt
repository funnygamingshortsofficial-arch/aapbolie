package com.aapbolie

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

/** Samsung फोन पर ऐप के ऊपर छोटा Dynamic-Island-जैसा status pill। */
class IslandService : Service() {
  private var wm: WindowManager? = null
  private var pill: TextView? = null
  override fun onBind(intent: Intent?): IBinder? = null
  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
    if (pill == null) showPill()
    return START_NOT_STICKY
  }
  private fun showPill() {
    if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
    wm = getSystemService(WINDOW_SERVICE) as WindowManager
    val bg = GradientDrawable().apply { setColor(Color.rgb(35, 28, 24)); cornerRadius = 90f; setStroke(2, Color.rgb(220, 145, 60)) }
    val view = TextView(this).apply {
      text = "●  आप बोलिए  ·  तैयार"
      setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
      gravity = Gravity.CENTER; background = bg; setPadding(30, 14, 30, 14)
    }
    val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
      PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 34 }
    runCatching { wm?.addView(view, lp); pill = view }.onFailure { stopSelf() }
  }
  override fun onDestroy() { runCatching { pill?.let { wm?.removeView(it) } }; pill = null; super.onDestroy() }
}
