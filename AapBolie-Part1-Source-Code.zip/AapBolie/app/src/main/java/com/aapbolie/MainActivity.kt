package com.aapbolie
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.io.File

class MainActivity : ComponentActivity() {
  override fun onCreate(b: Bundle?) { super.onCreate(b); val p = Prefs(this); val v = Voice(this)
    setContent { AppTheme(p) { var tab by remember { mutableStateOf(0) }; val cs = MaterialTheme.colorScheme
      Scaffold(Modifier.background(cs.background).background(Brush.verticalGradient(listOf(cs.background, cs.primary.copy(alpha = .2f), cs.secondary.copy(alpha = .12f)))), containerColor = Color.Transparent, contentColor = cs.onBackground,
        bottomBar = { NavigationBar(containerColor = cs.surface.copy(alpha = .92f)) { listOf("🎙 लाइव", "⌨ कमांड", "⚙ सेटिंग्स").forEachIndexed { i, t ->
          NavigationBarItem(tab == i, { tab = i }, { }, label = { Text(t) }) } } }) { pad ->
        Box(Modifier.padding(pad).padding(16.dp).fillMaxSize()) { when (tab) { 0 -> Live(p, v); 1 -> Home(p); else -> SettingsScreen(p) } } } } } }
}
@Composable fun Glass(content: @Composable ColumnScope.() -> Unit) = Card(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp),
  CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .78f), contentColor = MaterialTheme.colorScheme.onSurface)) { Column(Modifier.padding(14.dp), content = content) }
@Composable fun Head(t: String) = Text(t, Modifier.padding(top = 16.dp, bottom = 2.dp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)

@Composable fun Live(p: Prefs, v: Voice) {
  val ctx = LocalContext.current; val scope = rememberCoroutineScope(); val cs = MaterialTheme.colorScheme
  var st by remember { mutableStateOf(0) }; var active by remember { mutableStateOf(false) }
  var activeOffline by remember { mutableStateOf(false) }
  val msgs = remember { mutableStateListOf<String>() }
  var draft by remember { mutableStateOf("") }
  var lastReply by remember { mutableStateOf("") }
  var dictating by remember { mutableStateOf(false) }
  fun turn(offline: Boolean) {
    if (!active) { st = 0; return }
    st = 1
    v.listen(langCode(p), offline, { t ->
      msgs += "🧑 $t"; st = 2
      scope.launch {
        val r = withContext(Dispatchers.IO) { route(ctx, p, t) }
        msgs += "🤖 $r"; lastReply = r; st = 3
        if (p.b("speak", true)) v.speak(r, p.f("speed", 1f), p.f("pitch", 1f), langCode(p)) { scope.launch { delay(450); turn(offline) } }
        else { scope.launch { delay(250); turn(offline) } }
      }
    }, { active = false; st = 0 })
  }
  val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
    if (granted) { active = true; turn(activeOffline) }
  }
  val dictationPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
    if (granted) {
      dictating = true
      v.listen(langCode(p), p.s("mode", "Auto") == "Offline", { text -> draft = text; dictating = false }, { dictating = false })
    }
  }
  fun startDictation() {
    if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
      dictating = true
      v.listen(langCode(p), p.s("mode", "Auto") == "Offline", { text -> draft = text; dictating = false }, { dictating = false })
    } else dictationPerm.launch(Manifest.permission.RECORD_AUDIO)
  }
  fun sendDraft() {
    val text = draft.trim()
    if (text.isBlank()) return
    draft = ""; msgs += "🧑 $text"
    scope.launch {
      val reply = withContext(Dispatchers.IO) { route(ctx, p, text) }
      msgs += "🤖 $reply"; lastReply = reply
      if (p.b("speak", true)) v.speak(reply, p.f("speed", 1f), p.f("pitch", 1f), langCode(p)) {}
    }
  }
  fun start(offline: Boolean) {
    if (active) { active = false; st = 0; v.stop(); return }
    if (offline && !Offline.ready(ctx)) {
      Toast.makeText(ctx, "पहले सेटिंग्स → ऑफलाइन में Gemma 3 1B डाउनलोड करें।", Toast.LENGTH_LONG).show()
      return
    }
    activeOffline = offline
    p.put("mode", if (offline) "Offline" else "Online")
    if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
      active = true; turn(offline)
    } else perm.launch(Manifest.permission.RECORD_AUDIO)
  }
  val tr = rememberInfiniteTransition(label = "voice-pulse")
  val scale by tr.animateFloat(1f, if (st == 0) 1.035f else 1.12f,
    infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "voice-scale")
  LazyColumn(
    modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 18.dp)
  ) {
    item {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("आप बोलिए", fontSize = 32.sp, color = cs.primary)
        Text("आपका स्मार्ट वॉइस असिस्टेंट", color = cs.onSurface.copy(alpha = .72f))
      Text("जवाब के बाद यह फिर सुनेगा — रोकने तक बातचीत जारी रहेगी", color = cs.secondary, fontSize = 12.sp)
      }
    }
    item {
      Box(Modifier.size(164.dp).scale(scale).clip(CircleShape)
        .background(Brush.radialGradient(listOf(cs.secondary, cs.primary, cs.primary.copy(alpha = .3f)))),
        contentAlignment = Alignment.Center) {
        Text(listOf("✦", "◉", "⋯", "♫")[st], fontSize = 56.sp, color = Color.White)
      }
    }
    item {
      Text(listOf("मोड चुनें और बोलना शुरू करें", "सुन रहा हूँ…", "सोच रहा हूँ…", "जवाब दे रहा हूँ…")[st],
        fontSize = 17.sp, color = cs.onBackground)
    }
    item {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { start(false) }, modifier = Modifier.weight(1f).height(54.dp),
          shape = RoundedCornerShape(18.dp), enabled = !active || !activeOffline) {
          Text(if (active && !activeOffline) "■ ऑनलाइन रोकें" else "☁ ऑनलाइन")
        }
        OutlinedButton(onClick = { start(true) }, modifier = Modifier.weight(1f).height(54.dp),
          shape = RoundedCornerShape(18.dp), enabled = !active || activeOffline) {
          Text(if (active && activeOffline) "■ ऑफलाइन रोकें" else "◉ ऑफलाइन")
        }
      }
    }
    item {
      Text(if (online(ctx)) "इंटरनेट कनेक्शन उपलब्ध" else "इंटरनेट उपलब्ध नहीं", color = cs.secondary, fontSize = 12.sp)
    }
    item {
      Glass {
        Text("बोलकर लिखें / Text to Speech", style = MaterialTheme.typography.titleMedium, color = cs.primary)
        Text("माइक से आपकी आवाज़ टेक्स्ट बनेगी। भेजने पर AI का जवाब टेक्स्ट और आवाज़—दोनों में मिलेगा।", color = cs.onSurface.copy(alpha = .72f), fontSize = 13.sp)
        OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.fillMaxWidth(), label = { Text("आपका टेक्स्ट") }, minLines = 2)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(onClick = { startDictation() }, modifier = Modifier.weight(1f), enabled = !dictating) { Text(if (dictating) "सुन रहा हूँ…" else "🎤 बोलकर लिखें") }
          Button(onClick = { sendDraft() }, modifier = Modifier.weight(1f), enabled = draft.isNotBlank()) { Text("भेजें") }
        }
        OutlinedButton(onClick = { if (lastReply.isNotBlank()) v.speak(lastReply, p.f("speed", 1f), p.f("pitch", 1f), langCode(p)) {} }, modifier = Modifier.fillMaxWidth(), enabled = lastReply.isNotBlank()) { Text("🔊 आखिरी जवाब फिर सुनें") }
      }
    }
    item {
      Glass {
        Text("बातचीत", style = MaterialTheme.typography.titleMedium, color = cs.primary)
        if (msgs.isEmpty()) Text("आपकी बातचीत यहाँ दिखाई देगी।", color = cs.onSurface.copy(alpha = .65f))
        else msgs.takeLast(12).forEach { Text(it, Modifier.padding(vertical = 4.dp)) }
      }
    }
  }
}
@Composable fun Home(p: Prefs) {
  val ctx = LocalContext.current; val scope = rememberCoroutineScope()
  var cmd by remember { mutableStateOf("") }; var out by remember { mutableStateOf("") }
  Column(Modifier.fillMaxSize().then(Modifier), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("कमांड लिखकर चलाएँ", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
    OutlinedTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), label = { Text("जैसे: Claude खोलो और hello भेजो") }, shape = RoundedCornerShape(18.dp))
    Button({ scope.launch { out = "चल रहा है…"; out = withContext(Dispatchers.IO) { route(ctx, p, cmd) } } }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp)) { Text("चलाओ") }
    Glass { Text("Accessibility चालू करने के लिए: पहले नीचे वाला बटन (App info) → ⋮ → \"Allow restricted settings\", फिर Accessibility में 'आप बोलिए' ऑन करें।")
      Spacer(Modifier.height(8.dp))
      OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }, Modifier.fillMaxWidth()) { Text("1. App info खोलें") }
      OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("2. Accessibility खोलें") } }
    Text(out)
  }
}
@OptIn(ExperimentalLayoutApi::class)
@Composable fun AiSetup(p: Prefs) {
  var sel by remember { mutableStateOf(p.s("provider", "gemini")) }; val v = PROVS.first { it.id == sel }
  var key by remember(sel) { mutableStateOf(p.s("key_$sel")) }; var model by remember(sel) { mutableStateOf(p.s("model_$sel", v.model)) }
  var base by remember { mutableStateOf(p.s("base_custom", PROVS.last().base)) }; var msg by remember { mutableStateOf("") }
  val scope = rememberCoroutineScope()
  Glass {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { PROVS.forEach { x -> FilterChip(sel == x.id, { sel = x.id }, { Text(x.name) }) } }
    OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("API Key") })
    OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("मॉडल") })
    if (sel == "custom") OutlinedTextField(base, { base = it }, Modifier.fillMaxWidth(), label = { Text("Base URL") })
    Button({ p.put("provider", sel); p.put("key_$sel", key); p.put("model_$sel", model); p.put("base_custom", base)
      scope.launch { msg = "जाँच रही है…"; msg = runCatching { withContext(Dispatchers.IO) { askCloud(p, "एक शब्द में 'हाँ' कहो") }; "✓ ${v.name} जुड़ गया" }.getOrElse { "✗ ${it.message?.take(120)}" } } },
      Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("सेव करो और कनेक्ट जाँचो") }
    Text(msg)
  }
}
@Composable fun OfflineModel() {
  val c = LocalContext.current
  var msg by remember { mutableStateOf(if (Offline.ready(c)) "✓ Gemma 3 1B ऑफलाइन मॉडल इंस्टॉल है" else "Gemma 3 1B डाउनलोड करने के लिए तैयार है") }
  var showConfirm by remember { mutableStateOf(false) }
  var progress by remember { mutableFloatStateOf(0f) }
  var downloading by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()
  Glass {
    Text("Gemma 3 1B — LiteRT-LM", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    Text("यह असली ऑफलाइन जनरेटिव AI मॉडल है। लगभग 557 MiB डाउनलोड होगा और फोन की निजी ऐप स्टोरेज में रहेगा। डाउनलोड के बाद इंटरनेट के बिना चैट कर सकेंगे। मॉडल पहली बार लोड होने में कुछ समय लग सकता है।", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .78f))
    Text(msg, color = MaterialTheme.colorScheme.secondary)
    if (downloading) {
      LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth())
      Text("डाउनलोड: ${(progress * 100).toInt()}%", color = MaterialTheme.colorScheme.onSurface)
    }
    Button(onClick = { showConfirm = true }, enabled = !downloading && !Offline.ready(c), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
      Text(if (Offline.ready(c)) "✓ Gemma इंस्टॉल है" else "Gemma डाउनलोड करें (557 MiB)")
    }
    OutlinedButton(onClick = {
      scope.launch {
        downloading = true; msg = "पुराना मॉडल बंद किया जा रहा है…"
        withContext(Dispatchers.IO) { Offline.reset() }
        val f = File(c.filesDir, "gemma3-1b-it-int4.litertlm")
        val part = File(c.filesDir, "gemma3-1b-it-int4.litertlm.part")
        val result = withContext(Dispatchers.IO) { runCatching { if (f.exists()) f.delete(); if (part.exists()) part.delete() } }
        msg = if (result.isSuccess) "मॉडल हट गया। स्टोरेज खाली हो गई।" else "मॉडल हटाने में समस्या हुई।"
        downloading = false; progress = 0f
      }
    }, enabled = !downloading && Offline.ready(c), modifier = Modifier.fillMaxWidth()) { Text("ऑफलाइन मॉडल हटाएँ") }
    Text("मॉडल आपके पूछने और अनुमति देने के बाद ही डाउनलोड होगा।", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
  }
  if (showConfirm) {
    AlertDialog(
      onDismissRequest = { showConfirm = false },
      title = { Text("Gemma डाउनलोड की अनुमति?") },
      text = { Text("Gemma 3 1B INT4 का लगभग 557 MiB मॉडल डाउनलोड होगा। डाउनलोड Hugging Face से सीधे ऐप के अंदर होगा; कोई ब्राउज़र पेज नहीं खुलेगा। कम-से-कम 1 GB खाली स्टोरेज रखें। Gemma की उपयोग शर्तें लागू हैं। क्या डाउनलोड शुरू करें?") },
      confirmButton = { TextButton(onClick = {
        showConfirm = false
        scope.launch {
          downloading = true; progress = 0f; msg = "स्टोरेज और नेटवर्क जाँचे जा रहे हैं…"
          val result = withContext(Dispatchers.IO) {
            try {
            val dir = android.os.StatFs(c.filesDir.absolutePath)
            val required = 584_417_280L + 150L * 1024L * 1024L
            check(dir.availableBytes >= required) { "कम-से-कम 700 MiB से अधिक खाली जगह चाहिए। पहले स्टोरेज खाली करें।" }
            val target = File(c.filesDir, "gemma3-1b-it-int4.litertlm")
            val temp = File(c.filesDir, "gemma3-1b-it-int4.litertlm.part")
            val url = java.net.URL("https://huggingface.co/cuesetac/gemma-3-1b-it-litertlm/resolve/main/Gemma3-1B-IT_multi-prefill-seq_q4_ekv4096.litertlm")
            val conn = (url.openConnection() as java.net.HttpURLConnection).apply { connectTimeout = 30000; readTimeout = 90000; instanceFollowRedirects = true; setRequestProperty("User-Agent", "AapBolie-Android/1.0") }
            try {
              val code = conn.responseCode
              check(code in 200..299) { "डाउनलोड सर्वर ने HTTP $code दिया। इंटरनेट/लिंक फिर जाँचें।" }
              val total = conn.contentLengthLong.takeIf { it > 0 } ?: 584_417_280L
              conn.inputStream.use { input -> temp.outputStream().buffered().use { output ->
                val buf = ByteArray(128 * 1024); var count = 0L; var last = 0
                while (true) {
                  val n = input.read(buf); if (n < 0) break
                  output.write(buf, 0, n); count += n
                  val pct = ((count * 100L) / total).toInt().coerceIn(0, 99)
                  if (pct != last) { last = pct; scope.launch { progress = pct / 100f; msg = "Gemma डाउनलोड हो रहा है… $pct%" } }
                }
              } }
              check(temp.length() > 500_000_000L) { "डाउनलोड अधूरा है (${temp.length()} bytes)। दोबारा कोशिश करें।" }
              val digest = java.security.MessageDigest.getInstance("SHA-256")
              temp.inputStream().buffered().use { input -> val buf = ByteArray(1024 * 1024); while (true) { val n = input.read(buf); if (n < 0) break; digest.update(buf, 0, n) } }
              val sha = digest.digest().joinToString("") { "%02x".format(it) }
              check(sha == "1325ae366d31950f137c9c357b9fa89448b176d76998180c08ceaca78bba98be") { "मॉडल की सुरक्षा जाँच (SHA-256) असफल हुई। फ़ाइल इंस्टॉल नहीं की गई।" }
              if (target.exists()) target.delete()
              check(temp.renameTo(target)) { "डाउनलोड फ़ाइल ऐप स्टोरेज में सेव नहीं हो पाई।" }
            } finally { conn.disconnect() }
            Result.success(Unit)
            } catch (error: Throwable) { Result.failure(error) }
          }
          result.fold(
            { progress = 1f; msg = "✓ Gemma डाउनलोड और SHA-256 जाँच सफल। अब ऑफलाइन मोड शुरू कर सकते हैं।" },
            { msg = "डाउनलोड नहीं हुआ: ${it.message?.take(220)}" }
          )
          downloading = false
        }
      }) { Text("हाँ, डाउनलोड करो") } },
      dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("रद्द करें") } }
    )
  }
}
@Composable fun SettingsScreen(p: Prefs) {
  LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
    item { Text("सेटिंग्स", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary) }
    SECTIONS.forEach { (title, opts) ->
      if (title.startsWith("🤖")) { item { Head("🔑 AI सेटअप") }; item { AiSetup(p) } }
      item { Head(title) }
      items(opts) { o -> Glass { OptRow(p, o) } }
      if (title.startsWith("💾")) item { OfflineModel() }
    }
  }
}
@OptIn(ExperimentalLayoutApi::class)
@Composable fun OptRow(p: Prefs, o: Opt) {
  when (o) {
    is Tog -> { var v by remember { mutableStateOf(p.b(o.key, o.def)) }
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(o.title, Modifier.weight(1f)); Switch(v, { v = it; p.put(o.key, it) }) } }
    is Sli -> { var v by remember { mutableStateOf(p.f(o.key, o.def)) }
      Text("${o.title}: ${"%.1f".format(v)}"); Slider(v, { v = it; p.put(o.key, it) }, valueRange = o.lo..o.hi) }
    is Pick -> { var v by remember { mutableStateOf(p.s(o.key, o.items[0])) }
      Text(o.title); FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        o.items.forEach { i -> FilterChip(v == i, { v = i; p.put(o.key, i) }, { Text(i, maxLines = 1) }) } } }
  }
}
