package com.aapbolie

import android.content.Context
import android.net.ConnectivityManager
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Mutex
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** kind: 0 = OpenAI-compatible API, 1 = Gemini, 2 = Anthropic */
data class Prov(val id: String, val name: String, val base: String, val model: String, val kind: Int)
val PROVS = listOf(
  Prov("gemini", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash", 1),
  Prov("claude", "Anthropic Claude", "https://api.anthropic.com/v1", "claude-sonnet-4-5", 2),
  Prov("openai", "OpenAI", "https://api.openai.com/v1", "gpt-4o-mini", 0),
  Prov("groq", "Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", 0),
  Prov("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", 0),
  Prov("deepseek", "DeepSeek", "https://api.deepseek.com/v1", "deepseek-chat", 0),
  Prov("custom", "Custom / Ollama", "http://192.168.1.2:11434/v1", "llama3", 0))

fun online(c: Context) = (c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).activeNetwork != null

private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
  val h = URL(url).openConnection() as HttpURLConnection
  h.requestMethod = "POST"; h.doOutput = true; h.connectTimeout = 20000; h.readTimeout = 90000
  h.setRequestProperty("Content-Type", "application/json"); headers.forEach { (k, v) -> h.setRequestProperty(k, v) }
  h.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
  val code = h.responseCode
  val s = (if (code < 400) h.inputStream else h.errorStream).bufferedReader().use { it.readText() }
  h.disconnect()
  if (code >= 400) error("API $code: ${s.take(300)}")
  return s
}

data class ChatTurn(val user: String, val assistant: String)
object ChatMemory {
  private val turns = mutableListOf<ChatTurn>()
  @Synchronized fun snapshot(): List<ChatTurn> = turns.takeLast(10).toList()
  @Synchronized fun add(user: String, assistant: String) { turns += ChatTurn(user, assistant); while (turns.size > 10) turns.removeAt(0) }
  @Synchronized fun clear() = turns.clear()
}

fun askCloud(p: Prefs, prompt: String): String = askCloud(p, prompt, emptyList())
fun askCloud(p: Prefs, prompt: String, history: List<ChatTurn>): String {
  val v = PROVS.firstOrNull { it.id == p.s("provider", "gemini") } ?: PROVS.first()
  val key = p.s("key_${v.id}"); require(key.isNotBlank()) { "पहले AI सेटिंग्स में API Key डालें।" }
  val model = p.s("model_${v.id}", v.model)
  val base = if (v.id == "custom") p.s("base_custom", v.base) else v.base
  val temp = p.f("temp", 0.7f).toDouble()
  val system = "तुम 'आप बोलिए' नाम के मददगार हिंदी वॉइस असिस्टेंट हो। यूज़र की भाषा में साफ, सुरक्षित और उपयोगी जवाब दो।"
  return when (v.kind) {
    1 -> {
      val contents = JSONArray()
      history.forEach { turn ->
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", turn.user))))
        contents.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", turn.assistant))))
      }
      contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
      val json = JSONObject(post("$base/models/$model:generateContent?key=$key", emptyMap(), JSONObject()
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        .put("contents", contents).put("generationConfig", JSONObject().put("temperature", temp))))
      json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
    2 -> {
      val messages = JSONArray()
      history.forEach { turn -> messages.put(JSONObject().put("role", "user").put("content", turn.user)); messages.put(JSONObject().put("role", "assistant").put("content", turn.assistant)) }
      messages.put(JSONObject().put("role", "user").put("content", prompt))
      JSONObject(post("$base/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), JSONObject()
        .put("model", model).put("max_tokens", 1200).put("system", system).put("messages", messages)))
        .getJSONArray("content").getJSONObject(0).getString("text")
    }
    else -> {
      val messages = JSONArray().put(JSONObject().put("role", "system").put("content", system))
      history.forEach { turn -> messages.put(JSONObject().put("role", "user").put("content", turn.user)); messages.put(JSONObject().put("role", "assistant").put("content", turn.assistant)) }
      messages.put(JSONObject().put("role", "user").put("content", prompt))
      JSONObject(post("$base/chat/completions", mapOf("Authorization" to "Bearer $key"), JSONObject()
        .put("model", model).put("temperature", temp).put("messages", messages)))
        .getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
  }
}

/** Gemma 3 1B INT4 via LiteRT-LM. The model is downloaded only after in-app consent. */
object Offline {
  private const val MODEL_FILE = "gemma3-1b-it-int4.litertlm"
  private fun file(c: Context) = File(c.filesDir, MODEL_FILE)
  private val mutex = Mutex()
  private var engine: Engine? = null
  private var conversation: Conversation? = null

  fun ready(c: Context) = file(c).let { it.exists() && it.length() > 500_000_000L }
  fun modelSize(c: Context) = file(c).takeIf { it.exists() }?.length() ?: 0L

  private fun initialize(c: Context) {
    if (conversation != null) return
    check(ready(c)) { "Gemma मॉडल डाउनलोड नहीं है। सेटिंग्स → ऑफलाइन AI से डाउनलोड करें।" }
    val e = Engine(EngineConfig(modelPath = file(c).absolutePath, backend = Backend.CPU(), cacheDir = c.cacheDir.absolutePath))
    try {
      e.initialize()
      val cfg = ConversationConfig(
        systemInstruction = Contents.of("तुम आप बोलिए नाम के सहायक हो। हिंदी या यूज़र की भाषा में छोटे, स्पष्ट, सुरक्षित और उपयोगी जवाब दो। बातचीत का संदर्भ याद रखो।"),
        samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = 0.7)
      )
      engine = e
      conversation = e.createConversation(cfg)
    } catch (t: Throwable) { runCatching { e.close() }; throw t }
  }

  suspend fun ask(c: Context, prompt: String): String {
    mutex.lock()
    try {
      initialize(c)
      val result = StringBuilder()
      conversation!!.sendMessageAsync(prompt).collect { part -> result.append(part.toString()) }
      return result.toString().trim().ifBlank { "मॉडल ने खाली जवाब दिया। फिर कोशिश करें।" }
    } finally { mutex.unlock() }
  }

  suspend fun reset() {
    mutex.lock()
    try {
      runCatching { conversation?.close() }; conversation = null
      runCatching { engine?.close() }; engine = null
    } finally { mutex.unlock() }
  }
}

fun useCloud(c: Context, p: Prefs) = p.s("mode", "Auto").let {
  it == "Online" || (it == "Auto" && online(c) && p.s("key_${p.s("provider", "gemini")}").isNotBlank())
}

suspend fun chat(c: Context, p: Prefs, t: String): String {
  val prompt = t.trim()
  val remember = p.b("memory", true) && !p.b("incognito", false)
  if (!remember) {
    ChatMemory.clear()
    Offline.reset() // Do not retain the previous local conversation in incognito/no-memory mode.
  }
  val history = if (remember) ChatMemory.snapshot() else emptyList()
  val answer = if (useCloud(c, p)) {
    try { askCloud(p, prompt, history) }
    catch (err: Throwable) {
      if (p.b("fallback", true) && Offline.ready(c)) {
        try { Offline.ask(c, prompt) } catch (offlineError: Throwable) { "ऑफलाइन AI नहीं चला: ${offlineError.message?.take(160)}" }
      } else "ऑनलाइन AI में समस्या: ${err.message?.take(160)}"
    }
  } else {
    try { Offline.ask(c, prompt) } catch (err: Throwable) { "ऑफलाइन AI नहीं चला: ${err.message?.take(180)}" }
  }
  if (remember && answer.isNotBlank()) ChatMemory.add(prompt, answer)
  return answer
}

/** फोन-कमांड का छोटा सुरक्षित router; सामान्य बातचीत AI को भेजी जाती है। */
suspend fun route(c: Context, p: Prefs, t: String): String {
  val steps = Agent.plan(c, p, t)
  if (steps.isEmpty()) return chat(c, p, t)
  val sb = StringBuilder(); Agent.run(c, steps) { sb.append(it).append('\n') }
  return if (sb.contains("✓")) "हो गया" else sb.toString().ifBlank { "कमांड पूरी नहीं हुई। Accessibility सेवा चालू है या नहीं जाँचें।" }
}
