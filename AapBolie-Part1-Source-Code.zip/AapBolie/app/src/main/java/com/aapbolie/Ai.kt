package com.aapbolie
import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import android.net.ConnectivityManager
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** kind: 0 = OpenAI-जैसा API, 1 = Gemini, 2 = Anthropic */
data class Prov(val id: String, val name: String, val base: String, val model: String, val kind: Int)
val PROVS = listOf(
  Prov("gemini", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash", 1),
  Prov("claude", "Anthropic Claude", "https://api.anthropic.com/v1", "claude-sonnet-5-5", 2),
  Prov("openai", "OpenAI", "https://api.openai.com/v1", "gpt-4o-mini", 0),
  Prov("groq", "Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", 0),
  Prov("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", 0),
  Prov("deepseek", "DeepSeek", "https://api.deepseek.com/v1", "deepseek-chat", 0),
  Prov("custom", "Custom / Ollama", "http://192.168.1.2:11434/v1", "llama3", 0))

fun online(c: Context) = (c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).activeNetwork != null

fun accessibilityEnabled(c: Context): Boolean {
  val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
  val expected = "${c.packageName}/${AutoService::class.java.name}"
  return enabled.split(':').any { it.equals(expected, true) || it.endsWith("/.AutoService", true) }
}

private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
  val h = URL(url).openConnection() as HttpURLConnection
  h.requestMethod = "POST"; h.doOutput = true; h.connectTimeout = 15000; h.readTimeout = 60000
  h.setRequestProperty("Content-Type", "application/json"); headers.forEach { (k, v) -> h.setRequestProperty(k, v) }
  h.outputStream.use { it.write(body.toString().toByteArray()) }
  val s = (if (h.responseCode < 400) h.inputStream else h.errorStream).bufferedReader().readText()
  if (h.responseCode >= 400) error("API ${h.responseCode}: $s"); return s
}

fun askCloud(p: Prefs, prompt: String): String {
  val v = PROVS.first { it.id == p.s("provider", "gemini") }
  val key = p.s("key_${v.id}"); val model = p.s("model_${v.id}", v.model)
  val base = if (v.id == "custom") p.s("base_custom", v.base) else v.base
  val temp = p.f("temp", 0.7f).toDouble()
  return when (v.kind) {
    1 -> JSONObject(post("$base/models/$model:generateContent?key=$key", emptyMap(), JSONObject()
      .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
      .put("generationConfig", JSONObject().put("temperature", temp))))
      .getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    2 -> JSONObject(post("$base/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), JSONObject()
      .put("model", model).put("max_tokens", 1024)
      .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))))
      .getJSONArray("content").getJSONObject(0).getString("text")
    else -> JSONObject(post("$base/chat/completions", mapOf("Authorization" to "Bearer $key"), JSONObject()
      .put("model", model).put("temperature", temp)
      .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))))
      .getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
  }
}

/** ऑफलाइन AI: फोन पर चलने वाला मॉडल (.task फ़ाइल) MediaPipe से चलता है, इंटरनेट नहीं लगता। */
object Offline {
  private var llm: LlmInference? = null
  private fun f(c: Context) = File(c.filesDir, "model.task")
  fun ready(c: Context) = f(c).exists() && f(c).length() > 1024 * 1024
  fun reset() { runCatching { llm?.close() }; llm = null }
  fun ask(c: Context, prompt: String): String {
    if (!ready(c)) return "ऑफलाइन मॉडल इंस्टॉल नहीं है। सेटिंग्स → ऑफलाइन में मॉडल चुनें।"
    return runCatching {
      if (llm == null) llm = LlmInference.createFromOptions(c, LlmInference.LlmInferenceOptions.builder().setModelPath(f(c).path).setMaxTokens(1024).build())
      llm!!.generateResponse(prompt)
    }.getOrElse { "मॉडल चल नहीं पाया: ${it.message?.take(100)}" }
  }
}
fun useCloud(c: Context, p: Prefs) = p.s("mode", "Auto").let { it == "Online" || (it == "Auto" && online(c) && p.s("key_${p.s("provider", "gemini")}").isNotBlank()) }
fun chat(c: Context, p: Prefs, t: String): String {
  val q = "तुम 'आप बोलिए' नाम के दोस्ताना हिंदी वॉइस असिस्टेंट हो। छोटे जवाब दो। यूज़र: $t"
  return if (useCloud(c, p)) runCatching { askCloud(p, q) }.getOrElse { if (p.b("fallback", true)) Offline.ask(c, q) else "त्रुटि: ${it.message?.take(100)}" } else Offline.ask(c, q)
}
/** कमांड हो तो फोन चलाओ, वरना बातचीत। */
suspend fun route(c: Context, p: Prefs, t: String): String {
  val steps = Agent.plan(c, p, t); if (steps.isEmpty()) return chat(c, p, t)
  val sb = StringBuilder(); Agent.run(c, steps) { sb.append(it) }
  return if (sb.contains("✓")) "हो गया" else "नहीं हो पाया। क्या Accessibility सेवा चालू है?"
}
