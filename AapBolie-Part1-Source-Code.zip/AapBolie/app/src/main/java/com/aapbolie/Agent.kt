package com.aapbolie
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.delay
import org.json.JSONArray

data class Step(val op: String, val arg: String = "")

object Agent {
  /** ऑफलाइन प्लानर: "X खोलो और Y भेजो" जैसे कमांड बिना इंटरनेट समझता है। */
  fun planOffline(cmd: String): List<Step> {
    val r = Regex("(.+?)\\s*(?:open|खोलो|खोलें|ओपन करो|ओपन)\\s*(?:करो)?\\s*(?:और|and|,)?\\s*(.*)", RegexOption.IGNORE_CASE)
    val m = Regex("^(?:open\\s+)?(.+?)\\s+(?:खोलो|खोलें|ओपन करो|ओपन)(?:\\s+और)?\\s*(.*)$", RegexOption.IGNORE_CASE).find(cmd.trim())
      ?: Regex("^open\\s+(\\S+)\\s*(?:and)?\\s*(.*)$", RegexOption.IGNORE_CASE).find(cmd.trim())
    if (m == null) return emptyList()
    val steps = mutableListOf(Step("open", m.groupValues[1].trim()))
    val rest = m.groupValues[2].replace(Regex("\\s*(?:भेजो|भेजें|send|सेंड करो)\\s*$", RegexOption.IGNORE_CASE), "").trim()
      .replace(Regex("^(?:उससे|उसमें|type|write)\\s*", RegexOption.IGNORE_CASE), "")
    if (rest.isNotEmpty()) { steps += Step("type", rest); if (m.groupValues[2].contains(Regex("भेज|send|सेंड", RegexOption.IGNORE_CASE))) steps += Step("send") }
    return steps
  }
  fun planOnline(p: Prefs, cmd: String): List<Step> {
    val out = askCloud(p, """फोन कंट्रोल प्लानर। सिर्फ JSON array दो, जैसे [{"op":"open","arg":"Claude"},{"op":"type","arg":"hello"},{"op":"send"}].
ops: open, type, click, send, back, home, wait. कमांड: $cmd""")
    val a = JSONArray(out.substringAfter("[").substringBeforeLast("]").let { "[$it]" })
    return (0 until a.length()).map { a.getJSONObject(it).let { o -> Step(o.getString("op"), o.optString("arg")) } }
  }
  fun plan(c: Context, p: Prefs, cmd: String): List<Step> {
    val mode = p.s("mode", "Auto")
    val useCloud = mode == "Online" || (mode == "Auto" && online(c) && p.s("key_${p.s("provider", "gemini")}").isNotBlank())
    return if (useCloud) runCatching { planOnline(p, cmd) }.getOrElse { planOffline(cmd) } else planOffline(cmd)
  }
  suspend fun run(c: Context, steps: List<Step>, log: (String) -> Unit) {
    val s = AutoService.inst ?: return log("पहले Accessibility सेवा चालू करें")
    for (st in steps) {
      log("▶ ${st.op} ${st.arg}")
      val ok = when (st.op) {
        "open" -> openApp(c, st.arg).also { delay(2000) }
        "type" -> retry { s.typeText(st.arg) }
        "send" -> retry { s.clickLabel("Send", "भेजें", "भेजो") }
        "click" -> retry { s.clickLabel(st.arg) }
        "back" -> s.back(); "home" -> s.home()
        else -> { delay(1000); true }
      }
      if (!ok) { log("✗ नहीं हो पाया: ${st.op}"); return }
    }
    log("✓ पूरा हुआ")
  }
  private suspend fun retry(f: () -> Boolean): Boolean { repeat(4) { if (f()) return true; delay(700) }; return false }
  private fun openApp(c: Context, name: String): Boolean {
    val pm = c.packageManager
    val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    val hit = l.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
    c.startActivity(pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
  }
}
