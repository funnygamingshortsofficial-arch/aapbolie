package com.aapbolie

import android.content.Context
import android.content.Intent
import android.provider.Settings
import kotlinx.coroutines.delay
import org.json.JSONArray

 data class Step(val op: String, val arg: String = "")

object Agent {
  /** सामान्य हिंदी/अंग्रेज़ी ऐप-कंट्रोल वाक्यों का स्थानीय नियम-आधारित पार्सर। */
  fun planOffline(cmd: String): List<Step> {
    val s = cmd.trim()
    if (s.isBlank()) return emptyList()
    val open = Regex("^(?:कृपया\\s+)?(?:ओपन|खोलो|खोलें|खोल|open)\\s+(.+?)(?:\\s+(?:और|then|फिर|and)\\s+(.+))?$", RegexOption.IGNORE_CASE).find(s)
      ?: Regex("^(.+?)\\s+(?:ओपन करो|खोलो|खोलें|open)(?:\\s+(?:और|फिर|and|then)\\s+(.+))?$", RegexOption.IGNORE_CASE).find(s)
      ?: return emptyList()
    val app = open.groupValues[1].trim().trimEnd('.', '।')
    val tail = open.groupValues.getOrElse(2) { "" }.trim()
    if (app.isBlank()) return emptyList()
    val steps = mutableListOf(Step("open", app))
    if (tail.isNotBlank()) {
      val text = tail.replace(Regex("^(?:उसमें|उस पर|उसको|message|मैसेज)\\s*", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\s*(?:भेज दो|भेजो|भेजें|send|सेंड कर दो|सेंड करो)$", RegexOption.IGNORE_CASE), "").trim()
      if (text.isNotBlank()) steps += Step("type", text)
      if (tail.contains(Regex("भेज|send|सेंड", RegexOption.IGNORE_CASE))) steps += Step("send")
    }
    return steps
  }

  fun planOnline(p: Prefs, cmd: String): List<Step> {
    val raw = askCloud(p, "फोन कंट्रोल प्लानर। सिर्फ JSON array दो, जैसे [{\"op\":\"open\",\"arg\":\"Claude\"},{\"op\":\"type\",\"arg\":\"hello\"},{\"op\":\"send\"}]. केवल open,type,click,send,back,home,wait स्वीकार हैं। कमांड: $cmd")
    val json = raw.substringAfter("[", "").substringBeforeLast("]", "")
    if (json.isBlank()) return emptyList()
    val a = JSONArray("[$json]")
    return (0 until a.length()).mapNotNull { i ->
      val o = a.optJSONObject(i) ?: return@mapNotNull null
      val op = o.optString("op")
      if (op !in setOf("open", "type", "click", "send", "back", "home", "wait")) null else Step(op, o.optString("arg"))
    }
  }

  fun plan(c: Context, p: Prefs, cmd: String): List<Step> {
    val mode = p.s("mode", "Auto")
    val cloud = mode == "Online" || (mode == "Auto" && online(c) && p.s("key_${p.s("provider", "gemini")}").isNotBlank())
    return if (cloud) runCatching { planOnline(p, cmd) }.getOrElse { planOffline(cmd) } else planOffline(cmd)
  }

  suspend fun run(c: Context, steps: List<Step>, log: (String) -> Unit) {
    val service = AutoService.inst
    if (service == null) return log("Accessibility सेवा चालू नहीं है। सेटिंग्स में जाकर 'आप बोलिए' सेवा चालू करें।")
    for (step in steps) {
      log("▶ ${step.op} ${step.arg}")
      val ok = when (step.op) {
        "open" -> openApp(c, step.arg).also { if (it) delay(1800) }
        "type" -> retry { AutoService.inst?.typeText(step.arg) == true }
        "send" -> retry { AutoService.inst?.clickLabel("Send", "भेजें", "भेजो", "सेंड") == true }
        "click" -> retry { AutoService.inst?.clickLabel(step.arg) == true }
        "back" -> AutoService.inst?.back() == true
        "home" -> AutoService.inst?.home() == true
        "wait" -> { delay(1200); true }
        else -> false
      }
      if (!ok) { log("✗ नहीं हो पाया: ${step.op}। ऐप/स्क्रीन की स्थिति जाँचें।"); return }
    }
    log("✓ पूरा हुआ")
  }
  private suspend fun retry(f: () -> Boolean): Boolean { repeat(4) { if (f()) return true; delay(650) }; return false }

  private fun openApp(c: Context, name: String): Boolean {
    val pm = c.packageManager
    val intents = listOf(
      Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
      Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
    )
    val matches = intents.flatMap { intent -> pm.queryIntentActivities(intent, 0) }
    val aliases = when (name.lowercase()) {
      "यूट्यूब", "youtube" -> listOf("youtube")
      "क्लॉड", "क्लाउड", "claude" -> listOf("claude")
      "क्रोम", "chrome" -> listOf("chrome")
      "व्हाट्सएप", "whatsapp" -> listOf("whatsapp")
      else -> listOf(name.lowercase())
    }
    val hit = matches.firstOrNull { item -> aliases.any { item.loadLabel(pm).toString().lowercase().contains(it) } } ?: return false
    val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return runCatching { c.startActivity(launch); true }.getOrDefault(false)
  }
}
