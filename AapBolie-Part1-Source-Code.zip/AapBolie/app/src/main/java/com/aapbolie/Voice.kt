package com.aapbolie

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

fun langCode(p: Prefs) = mapOf(
  "हिंदी" to "hi-IN", "English" to "en-IN", "मराठी" to "mr-IN",
  "বাংলা" to "bn-IN", "ગુજરાતી" to "gu-IN"
)[p.s("speak_lang", "हिंदी")] ?: "hi-IN"

class Voice(private val c: Context) {
  private val h = Handler(Looper.getMainLooper())
  private var sr: SpeechRecognizer? = null
  private val tts = TextToSpeech(c) { status ->
    if (status == TextToSpeech.ERROR) show("फोन का Text-to-Speech इंजन उपलब्ध नहीं है।")
  }

  private fun show(message: String) = h.post {
    Toast.makeText(c, message, Toast.LENGTH_LONG).show()
  }

  fun speak(t: String, speed: Float, pitch: Float, lang: String, done: () -> Unit) {
    val locale = Locale.forLanguageTag(lang)
    val result = tts.setLanguage(locale)
    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
      show("इस भाषा की आवाज़ फोन में इंस्टॉल नहीं है। Text-to-Speech में भाषा डाउनलोड करें।")
    }
    tts.setSpeechRate(speed.coerceIn(0.5f, 2f))
    tts.setPitch(pitch.coerceIn(0.5f, 2f))
    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
      override fun onStart(id: String?) {}
      override fun onDone(id: String?) { h.post(done) }
      override fun onError(id: String?) { h.post(done) }
    })
    tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "aapbolie-${System.currentTimeMillis()}")
  }

  fun listen(lang: String, offline: Boolean, ok: (String) -> Unit, err: () -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(c)) {
      show("इस फोन में Speech Recognition Service उपलब्ध नहीं है।")
      err(); return
    }
    if (offline && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !SpeechRecognizer.isOnDeviceRecognitionAvailable(c)) {
      show("फोन में Offline Voice Engine उपलब्ध नहीं है। Settings में हिंदी Offline Speech भाषा डाउनलोड करें, या Online Mode चुनें।")
      err(); return
    }

    sr?.destroy()
    sr = try {
      if (offline && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        SpeechRecognizer.createOnDeviceSpeechRecognizer(c)
      else SpeechRecognizer.createSpeechRecognizer(c)
    } catch (_: Exception) {
      show("Voice Engine शुरू नहीं हो पाया। फोन की Speech Services जाँचें।")
      err(); return
    }

    sr?.setRecognitionListener(object : RecognitionListener {
      override fun onReadyForSpeech(params: Bundle?) {}
      override fun onBeginningOfSpeech() {}
      override fun onRmsChanged(rmsdB: Float) {}
      override fun onBufferReceived(buffer: ByteArray?) {}
      override fun onEndOfSpeech() {}
      override fun onEvent(eventType: Int, params: Bundle?) {}
      override fun onPartialResults(partialResults: Bundle?) {}
      override fun onError(error: Int) {
        val message = when (error) {
          SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "त्रुटि (13): इस भाषा का Offline Voice Pack डाउनलोड नहीं है। फोन की Settings → भाषा/Voice input → Offline speech recognition में ${lang.substringBefore('-')} भाषा डाउनलोड करें।"
          SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "यह भाषा Offline Voice Recognition में समर्थित नहीं है। दूसरी भाषा या Online Mode चुनें।"
          SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक्रोफोन अनुमति नहीं मिली। ऐप की Permissions में Microphone चालू करें।"
          SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice Engine व्यस्त है। एक पल बाद फिर कोशिश करें।"
          SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Voice Recognition को नेटवर्क नहीं मिला। Offline भाषा पैक जाँचें या Online Mode चुनें।"
          SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "आवाज़ समझ नहीं आई। फिर से बोलें।"
          else -> "Voice Recognition त्रुटि ($error)। Speech Services और भाषा पैक जाँचें।"
        }
        show(message)
        err()
      }
      override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (text.isNullOrBlank()) { show("आवाज़ समझ नहीं आई। फिर से बोलें।"); err() }
        else ok(text)
      }
    })

    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline)
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }
    try { sr?.startListening(intent) } catch (_: Exception) {
      show("माइक्रोफोन शुरू नहीं हो पाया। ऐप बंद करके दोबारा खोलें।")
      err()
    }
  }

  fun stop() {
    try { sr?.stopListening(); sr?.destroy() } catch (_: Exception) {}
    sr = null
    tts.stop()
  }
}
