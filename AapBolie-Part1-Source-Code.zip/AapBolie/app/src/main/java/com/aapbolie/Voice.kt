package com.aapbolie

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

fun langCode(p: Prefs) = mapOf("हिंदी" to "hi-IN", "English" to "en-IN", "मराठी" to "mr-IN", "বাংলা" to "bn-BD", "ગુજરાતી" to "gu-IN")[p.s("speak_lang", "हिंदी")] ?: "hi-IN"

class Voice(private val c: Context) {
  private val h = Handler(Looper.getMainLooper())
  private var sr: SpeechRecognizer? = null
  private val tts = TextToSpeech(c) { status -> if (status == TextToSpeech.SUCCESS) ttsReady = true }
  @Volatile private var ttsReady = false

  fun speak(t: String, speed: Float, pitch: Float, lang: String, done: () -> Unit) {
    if (!ttsReady) { h.post(done); return }
    val locale = Locale.forLanguageTag(lang)
    val result = tts.setLanguage(locale)
    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) { h.post(done); return }
    tts.setSpeechRate(speed); tts.setPitch(pitch)
    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
      override fun onStart(id: String?) {}
      override fun onDone(id: String?) { h.post(done) }
      override fun onError(id: String?) { h.post(done) }
    })
    tts.speak(t, TextToSpeech.QUEUE_FLUSH, Bundle(), "aapbolie-${System.currentTimeMillis()}")
  }

  fun listen(lang: String, preferOffline: Boolean, ok: (String) -> Unit, err: (String) -> Unit) {
    runCatching {
      sr?.destroy()
      sr = if (preferOffline && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(c))
        SpeechRecognizer.createOnDeviceSpeechRecognizer(c)
      else SpeechRecognizer.createSpeechRecognizer(c)
      sr!!.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(r: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, b: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {}
        override fun onError(e: Int) { h.post { err(errorName(e, preferOffline)) } }
        override fun onResults(b: Bundle?) {
          val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
          h.post { if (text.isNullOrBlank()) err("आवाज़ समझ नहीं आई। फिर कोशिश करें।") else ok(text) }
        }
      })
      val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
        .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
      sr!!.startListening(intent)
    }.onFailure { err("माइक्रोफोन शुरू नहीं हुआ: ${it.message ?: "अनजान त्रुटि"}") }
  }

  private fun errorName(code: Int, offline: Boolean) = when (code) {
    SpeechRecognizer.ERROR_AUDIO -> "माइक्रोफोन ऑडियो त्रुटि"
    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक्रोफोन अनुमति नहीं मिली"
    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> if (offline) "इस फोन में ऑफलाइन Speech Recognition उपलब्ध नहीं है। भाषा पैक डाउनलोड करें या Online Voice चुनें।" else "इंटरनेट कनेक्शन जाँचें।"
    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "आवाज़ नहीं मिली। दोबारा बोलें।"
    else -> "Voice Recognition त्रुटि ($code)"
  }
  fun stop() { sr?.cancel(); sr?.destroy(); sr = null; tts.stop() }
  fun release() { stop(); tts.shutdown() }
}
