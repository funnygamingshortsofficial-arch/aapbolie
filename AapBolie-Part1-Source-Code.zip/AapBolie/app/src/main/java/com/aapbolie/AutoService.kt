package com.aapbolie

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Android Accessibility के जरिए स्क्रीन पर उपलब्ध UI से इंटरैक्शन। */
class AutoService : AccessibilityService() {
  companion object { @Volatile var inst: AutoService? = null }
  override fun onServiceConnected() { super.onServiceConnected(); inst = this }
  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}
  override fun onDestroy() { if (inst === this) inst = null; super.onDestroy() }

  private fun all(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo> = mutableListOf()): MutableList<AccessibilityNodeInfo> {
    if (n == null) return out
    out += n
    for (i in 0 until n.childCount) all(n.getChild(i), out)
    return out
  }
  fun screenText(): String = runCatching { all(rootInActiveWindow).mapNotNull { it.text ?: it.contentDescription }.joinToString("\n") }.getOrDefault("")

  fun typeText(t: String): Boolean {
    val nodes = all(rootInActiveWindow)
    val box = nodes.firstOrNull { it.isFocused && it.isEditable }
      ?: nodes.firstOrNull { it.isEditable && it.isVisibleToUser } ?: return false
    box.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
    val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
    return box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
  }

  fun clickLabel(vararg labels: String): Boolean {
    val wanted = labels.map { it.trim().lowercase() }
    for (n in all(rootInActiveWindow)) {
      val value = (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase() ?: continue
      if (wanted.any { value == it || value.contains(it) }) {
        var target: AccessibilityNodeInfo? = n
        while (target != null && !target.isClickable) target = target.parent
        if (target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
      }
    }
    return false
  }
  fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
  fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
  fun tap(x: Float, y: Float): Boolean {
    val p = Path().apply { moveTo(x, y) }
    val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build()
    return dispatchGesture(g, null, null)
  }
}
