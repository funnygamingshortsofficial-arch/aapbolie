package com.aapbolie
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.*

/** फोन का कंट्रोल: स्क्रीन पढ़ना, टैप, टाइप, स्वाइप, बैक/होम। */
class AutoService : AccessibilityService() {
  companion object { var inst: AutoService? = null }
  override fun onServiceConnected() { inst = this }
  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}
  override fun onDestroy() { inst = null; super.onDestroy() }

  private fun all(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo> = mutableListOf()): MutableList<AccessibilityNodeInfo> {
    if (n == null) return out
    out += n; for (i in 0 until n.childCount) all(n.getChild(i), out); return out
  }
  fun screenText() = all(rootInActiveWindow).mapNotNull { it.text ?: it.contentDescription }.joinToString("\n")

  fun typeText(t: String): Boolean {
    val nodes = all(rootInActiveWindow)
    val box = nodes.firstOrNull { it.isFocused && it.isEditable } ?: nodes.firstOrNull { it.isEditable } ?: return false
    box.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
    val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
    return box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
  }
  fun clickLabel(vararg labels: String): Boolean {
    for (n in all(rootInActiveWindow)) {
      val s = (n.text ?: n.contentDescription)?.toString() ?: continue
      if (labels.any { s.equals(it, true) }) {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
      }
    }
    return false
  }
  fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 300) {
    val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
    dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
  }
  fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
  fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
}
