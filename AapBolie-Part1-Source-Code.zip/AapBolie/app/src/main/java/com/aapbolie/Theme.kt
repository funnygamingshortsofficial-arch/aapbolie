package com.aapbolie
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private fun c(h: Long) = Color(h)
fun scheme(theme: String, dark: Boolean) = when (theme) {
  "Sage Garden" -> if (dark) darkColorScheme(primary = c(0xFF9BC59D), background = c(0xFF1A211B), surface = c(0xFF242E25), secondary = c(0xFFE6C27A), onBackground = c(0xFFE9EFE4), onSurface = c(0xFFE9EFE4))
    else lightColorScheme(primary = c(0xFF3F7D4E), background = c(0xFFF3F6EC), surface = c(0xFFFFFFFF), secondary = c(0xFFC68B2C))
  "Plum Ink" -> if (dark) darkColorScheme(primary = c(0xFFE2A6D8), background = c(0xFF1F1422), surface = c(0xFF2D1D31), secondary = c(0xFFF2B35C), onBackground = c(0xFFF3E7F1), onSurface = c(0xFFF3E7F1))
    else lightColorScheme(primary = c(0xFF6B2D72), background = c(0xFFFAF2F8), surface = c(0xFFFFFFFF), secondary = c(0xFFD9822B))
  "Rose Clay" -> if (dark) darkColorScheme(primary = c(0xFFF0A08C), background = c(0xFF241816), surface = c(0xFF33211E), secondary = c(0xFF86C5BD), onBackground = c(0xFFF7E8E3), onSurface = c(0xFFF7E8E3))
    else lightColorScheme(primary = c(0xFFB8503C), background = c(0xFFFCF0EA), surface = c(0xFFFFFFFF), secondary = c(0xFF2E8B83))
  else -> if (dark) darkColorScheme(primary = c(0xFF9ADBCB), background = c(0xFF101418), surface = c(0xFF1B2229), secondary = c(0xFF9BB7F0), onBackground = c(0xFFE7EDF2), onSurface = c(0xFFE7EDF2))
    else lightColorScheme(primary = c(0xFF236B60), background = c(0xFFF4F7F8), surface = c(0xFFFFFFFF), secondary = c(0xFF526F9D))
}
@Composable fun AppTheme(p: Prefs, content: @Composable () -> Unit) {
  val dark = when (p.s("appearance", "सिस्टम जैसा")) { "डार्क" -> true; "लाइट" -> false; else -> isSystemInDarkTheme() }
  MaterialTheme(colorScheme = scheme(p.s("theme", "Midnight AI"), dark), content = content)
}
