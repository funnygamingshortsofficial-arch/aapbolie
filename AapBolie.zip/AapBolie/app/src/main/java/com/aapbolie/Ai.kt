package com.aapbolie
import android.content.Context
import android.net.ConnectivityManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** kind: 0 = OpenAI-जैसा API, 1 = Gemini, 2 = Anthropic */
data class Prov(val id: String, val name: String, val base: String, val model: String, val kind: Int)
val PROVS = listOf(
  Prov("gemini", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash", 1),
  Prov("claude", "Anthropic Claude", "https://api.anthropic.com/v1", "claude-sonnet-5-5", 2),
  Prov("openai", "OpenAI", "https://api.openai.com/v1", "gpt-4o-mini", 0),
  Prov("groq", "Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", 0),
  Prov("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", 0),
  Prov("deepseek", "DeepSeek", "https://api.deepseek.com/v1", "deepseek-chat", 0),
  Prov("custom", "Custom / Ollama", "http://192.168.1.2:11434/v1", "llama3", 0))

fun online(c: Context) = (c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).activeNetwork != null

private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
  val h = URL(url).openConnection() as HttpURLConnection
  h.requestMethod = "POST"; h.doOutput = true; h.connectTimeout = 15000; h.readTimeout = 60000
  h.setRequestProperty("Content-Type", "application/json"); headers.forEach { (k, v) -> h.setRequestProperty(k, v) }
  h.outputStream.use { it.write(body.toString().toByteArray()) }
  val s = (if (h.responseCode < 400) h.inputStream else h.errorStream).bufferedReader().readText()
  if (h.responseCode >= 400) error("API ${h.responseCode}: $s"); return s
}

fun askCloud(p: Prefs, prompt: String): String {
  val v = PROVS.first { it.id == p.s("provider", "gemini") }
  val key = p.s("key_${v.id}"); val model = p.s("model_${v.id}", v.model)
  val base = if (v.id == "custom") p.s("base_custom", v.base) else v.base
  val temp = p.f("temp", 0.7f).toDouble()
  return when (v.kind) {
    1 -> JSONObject(post("$base/models/$model:generateContent?key=$key", emptyMap(), JSONObject()
      .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
      .put("generationConfig", JSONObject().put("temperature", temp))))
      .getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    2 -> JSONObject(post("$base/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), JSONObject()
      .put("model", model).put("max_tokens", 1024)
      .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))))
      .getJSONArray("content").getJSONObject(0).getString("text")
    else -> JSONObject(post("$base/chat/completions", mapOf("Authorization" to "Bearer $key"), JSONObject()
      .put("model", model).put("temperature", temp)
      .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))))
      .getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
  }
}

/** ऑफलाइन AI का स्लॉट: यहाँ बाद में llama.cpp (JNI) + Gemma/Qwen .gguf जुड़ेगा। अभी नियम-आधारित। */
object Offline { fun ask(prompt: String): String = "ऑफलाइन मॉडल अभी जुड़ा नहीं है।" }
