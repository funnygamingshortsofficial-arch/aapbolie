package com.aapbolie
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
  override fun onCreate(b: Bundle?) { super.onCreate(b); val p = Prefs(this)
    setContent { AppTheme(p) { var tab by remember { mutableStateOf(0) }
      Scaffold(bottomBar = { NavigationBar { listOf("🎙 कमांड", "🤖 AI सेटअप", "⚙ सेटिंग्स").forEachIndexed { i, t ->
        NavigationBarItem(tab == i, { tab = i }, { }, label = { Text(t) }) } } }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background0()) { when (tab) { 0 -> Home(p); 1 -> AiSetup(p); else -> SettingsScreen(p) } } } } } }
}
@Composable private fun Modifier.background0() = this.then(Modifier.padding(16.dp))

@Composable fun Home(p: Prefs) {
  val ctx = LocalContext.current; val scope = rememberCoroutineScope()
  var cmd by remember { mutableStateOf("") }; val log = remember { mutableStateListOf<String>() }
  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("आप बोलिए", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
    Text(if (online(ctx)) "● ऑनलाइन" else "● ऑफलाइन", color = MaterialTheme.colorScheme.secondary)
    OutlinedTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), label = { Text("जैसे: Claude खोलो और hello भेजो") })
    Button({ scope.launch { log.clear(); val steps = withContext(Dispatchers.IO) { Agent.plan(ctx, p, cmd) }
        if (steps.isEmpty()) log += "कमांड समझ नहीं आया" else Agent.run(ctx, steps) { log += it } } },
      Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("चलाओ") }
    OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("Accessibility सेवा चालू करें") }
    log.forEach { Text(it) }
  }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AiSetup(p: Prefs) {
  var sel by remember { mutableStateOf(p.s("provider", "gemini")) }; val v = PROVS.first { it.id == sel }
  var key by remember(sel) { mutableStateOf(p.s("key_$sel")) }; var model by remember(sel) { mutableStateOf(p.s("model_$sel", v.model)) }
  var base by remember { mutableStateOf(p.s("base_custom", PROVS.last().base)) }; var msg by remember { mutableStateOf("") }
  val ctx = LocalContext.current; val scope = rememberCoroutineScope()
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Text("AI सेटअप", style = MaterialTheme.typography.headlineMedium)
    LazyColumn(Modifier.height(220.dp)) { items(PROVS) { x -> FilterChip(sel == x.id, { sel = x.id }, { Text(x.name) }, Modifier.padding(2.dp)) } }
    OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API Key") })
    OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("मॉडल") })
    if (sel == "custom") OutlinedTextField(base, { base = it }, Modifier.fillMaxWidth(), label = { Text("Base URL") })
    Button({ p.put("provider", sel); p.put("key_$sel", key); p.put("model_$sel", model); p.put("base_custom", base)
      scope.launch { msg = "जाँच रही है…"; msg = runCatching { withContext(Dispatchers.IO) { askCloud(p, "एक शब्द में 'हाँ' कहो") }; "✓ ${v.name} जुड़ गया" }.getOrElse { "✗ ${it.message?.take(120)}" } } },
      Modifier.fillMaxWidth()) { Text("सेव करो और कनेक्ट जाँचो") }
    Text(msg)
  }
}
@Composable fun SettingsScreen(p: Prefs) {
  LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    SECTIONS.forEach { (title, opts) ->
      item { Text(title, Modifier.padding(top = 14.dp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary) }
      items(opts) { o -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { OptRow(p, o) } } }
    }
  }
}
@Composable fun OptRow(p: Prefs, o: Opt) {
  when (o) {
    is Tog -> { var v by remember { mutableStateOf(p.b(o.key, o.def)) }
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(o.title); Switch(v, { v = it; p.put(o.key, it) }) } }
    is Sli -> { var v by remember { mutableStateOf(p.f(o.key, o.def)) }
      Text("${o.title}: ${"%.1f".format(v)}"); Slider(v, { v = it; p.put(o.key, it) }, valueRange = o.lo..o.hi) }
    is Pick -> { var v by remember { mutableStateOf(p.s(o.key, o.items[0])) }
      Text(o.title); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        o.items.take(4).forEach { i -> FilterChip(v == i, { v = i; p.put(o.key, i) }, { Text(i, maxLines = 1) }) } } }
  }
}
