package com.aapbolie
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.io.File

class MainActivity : ComponentActivity() {
  override fun onCreate(b: Bundle?) { super.onCreate(b); val p = Prefs(this); val v = Voice(this)
    setContent { AppTheme(p) { var tab by remember { mutableStateOf(0) }; val cs = MaterialTheme.colorScheme
      Scaffold(Modifier.background(Brush.verticalGradient(listOf(cs.background, cs.primary.copy(alpha = .2f), cs.secondary.copy(alpha = .12f)))), containerColor = Color.Transparent,
        bottomBar = { NavigationBar(containerColor = cs.surface.copy(alpha = .92f)) { listOf("🎙 लाइव", "⌨ कमांड", "⚙ सेटिंग्स").forEachIndexed { i, t ->
          NavigationBarItem(tab == i, { tab = i }, { }, label = { Text(t) }) } } }) { pad ->
        Box(Modifier.padding(pad).padding(16.dp).fillMaxSize()) { when (tab) { 0 -> Live(p, v); 1 -> Home(p); else -> SettingsScreen(p) } } } } } }
}
@Composable fun Glass(content: @Composable ColumnScope.() -> Unit) = Card(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp),
  CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .78f))) { Column(Modifier.padding(14.dp), content = content) }
@Composable fun Head(t: String) = Text(t, Modifier.padding(top = 16.dp, bottom = 2.dp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)

@Composable fun Live(p: Prefs, v: Voice) {
  val ctx = LocalContext.current; val scope = rememberCoroutineScope(); val cs = MaterialTheme.colorScheme
  var st by remember { mutableStateOf(0) }; var active by remember { mutableStateOf(false) }; val msgs = remember { mutableStateListOf<String>() }
  fun turn() { if (!active) { st = 0; return }; st = 1
    v.listen(langCode(p), !online(ctx), { t -> msgs += "🧑 $t"; st = 2
      scope.launch { val r = withContext(Dispatchers.IO) { route(ctx, p, t) }; msgs += "🤖 $r"; st = 3
        v.speak(r, p.f("speed", 1f), p.f("pitch", 1f), langCode(p)) { turn() } } }, { active = false; st = 0 }) }
  val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) { active = true; turn() } }
  fun toggle() { if (active) { active = false; st = 0; v.stop() }
    else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { active = true; turn() }
    else perm.launch(Manifest.permission.RECORD_AUDIO) }
  val tr = rememberInfiniteTransition(label = "o")
  val sc by tr.animateFloat(1f, if (st == 0) 1.04f else 1.2f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")
  Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
    Text("आप बोलिए", fontSize = 34.sp, color = cs.primary)
    Text(if (online(ctx)) "● ऑनलाइन" else "● ऑफलाइन", color = cs.secondary)
    Spacer(Modifier.height(8.dp))
    Box(Modifier.size(190.dp).scale(sc).clip(CircleShape).background(Brush.radialGradient(listOf(cs.secondary, cs.primary, cs.primary.copy(alpha = .35f)))).clickable { toggle() }, contentAlignment = Alignment.Center) {
      Text(listOf("🎙", "👂", "💭", "🔊")[st], fontSize = 54.sp) }
    Text(listOf("छूकर बोलिए", "सुन रहा हूँ…", "सोच रहा हूँ…", "बोल रहा हूँ…")[st], fontSize = 18.sp)
    Glass { LazyColumn(Modifier.heightIn(max = 260.dp)) { items(msgs.takeLast(8)) { Text(it, Modifier.padding(vertical = 3.dp)) } } }
  }
}
@Composable fun Home(p: Prefs) {
  val ctx = LocalContext.current; val scope = rememberCoroutineScope()
  var cmd by remember { mutableStateOf("") }; var out by remember { mutableStateOf("") }
  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("कमांड लिखकर चलाएँ", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
    OutlinedTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), label = { Text("जैसे: Claude खोलो और hello भेजो") }, shape = RoundedCornerShape(18.dp))
    Button({ scope.launch { out = "चल रहा है…"; out = withContext(Dispatchers.IO) { route(ctx, p, cmd) } } }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp)) { Text("चलाओ") }
    Glass { Text("Accessibility चालू करने के लिए: पहले नीचे वाला बटन (App info) → ⋮ → \"Allow restricted settings\", फिर Accessibility में 'आप बोलिए' ऑन करें।")
      Spacer(Modifier.height(8.dp))
      OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }, Modifier.fillMaxWidth()) { Text("1. App info खोलें") }
      OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("2. Accessibility खोलें") } }
    Text(out)
  }
}
@OptIn(ExperimentalLayoutApi::class)
@Composable fun AiSetup(p: Prefs) {
  var sel by remember { mutableStateOf(p.s("provider", "gemini")) }; val v = PROVS.first { it.id == sel }
  var key by remember(sel) { mutableStateOf(p.s("key_$sel")) }; var model by remember(sel) { mutableStateOf(p.s("model_$sel", v.model)) }
  var base by remember { mutableStateOf(p.s("base_custom", PROVS.last().base)) }; var msg by remember { mutableStateOf("") }
  val scope = rememberCoroutineScope()
  Glass {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { PROVS.forEach { x -> FilterChip(sel == x.id, { sel = x.id }, { Text(x.name) }) } }
    OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("API Key") })
    OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("मॉडल") })
    if (sel == "custom") OutlinedTextField(base, { base = it }, Modifier.fillMaxWidth(), label = { Text("Base URL") })
    Button({ p.put("provider", sel); p.put("key_$sel", key); p.put("model_$sel", model); p.put("base_custom", base)
      scope.launch { msg = "जाँच रही है…"; msg = runCatching { withContext(Dispatchers.IO) { askCloud(p, "एक शब्द में 'हाँ' कहो") }; "✓ ${v.name} जुड़ गया" }.getOrElse { "✗ ${it.message?.take(120)}" } } },
      Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("सेव करो और कनेक्ट जाँचो") }
    Text(msg)
  }
}
@Composable fun OfflineModel() {
  val c = LocalContext.current; var msg by remember { mutableStateOf(if (Offline.ready(c)) "✓ मॉडल इंस्टॉल है" else "मॉडल इंस्टॉल नहीं है") }
  val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { msg = "कॉपी हो रहा है…"
    Thread { runCatching { c.contentResolver.openInputStream(u)!!.use { i -> File(c.filesDir, "model.task").outputStream().use { o -> i.copyTo(o) } }; Offline.reset() }
      .onSuccess { msg = "✓ मॉडल इंस्टॉल हो गया" }.onFailure { msg = "✗ ${it.message}" } }.start() } }
  Glass { Text("ऑफलाइन AI मॉडल (.task फ़ाइल: Gemma / Qwen)"); Text(msg, color = MaterialTheme.colorScheme.secondary)
    Button({ pick.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("फ़ोन से मॉडल चुनें") } }
}
@Composable fun SettingsScreen(p: Prefs) {
  LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    SECTIONS.forEach { (title, opts) ->
      if (title.startsWith("🤖")) { item { Head("🔑 AI सेटअप") }; item { AiSetup(p) } }
      item { Head(title) }
      items(opts) { o -> Glass { OptRow(p, o) } }
      if (title.startsWith("💾")) item { OfflineModel() }
    }
  }
}
@Composable fun OptRow(p: Prefs, o: Opt) {
  when (o) {
    is Tog -> { var v by remember { mutableStateOf(p.b(o.key, o.def)) }
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(o.title, Modifier.weight(1f)); Switch(v, { v = it; p.put(o.key, it) }) } }
    is Sli -> { var v by remember { mutableStateOf(p.f(o.key, o.def)) }
      Text("${o.title}: ${"%.1f".format(v)}"); Slider(v, { v = it; p.put(o.key, it) }, valueRange = o.lo..o.hi) }
    is Pick -> { var v by remember { mutableStateOf(p.s(o.key, o.items[0])) }
      Text(o.title); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        o.items.take(4).forEach { i -> FilterChip(v == i, { v = i; p.put(o.key, i) }, { Text(i, maxLines = 1) }) } } }
  }
}
