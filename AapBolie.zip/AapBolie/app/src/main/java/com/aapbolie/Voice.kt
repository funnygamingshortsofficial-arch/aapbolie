package com.aapbolie
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

fun langCode(p: Prefs) = mapOf("हिंदी" to "hi-IN", "English" to "en-IN", "मराठी" to "mr-IN", "বাংলা" to "bn-IN", "ગુજરાતી" to "gu-IN")[p.s("speak_lang", "हिंदी")] ?: "hi-IN"

class Voice(private val c: Context) {
  private val h = Handler(Looper.getMainLooper()); private var sr: SpeechRecognizer? = null
  private val tts = TextToSpeech(c) { }
  fun speak(t: String, speed: Float, pitch: Float, lang: String, done: () -> Unit) {
    tts.language = Locale.forLanguageTag(lang); tts.setSpeechRate(speed); tts.setPitch(pitch)
    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
      override fun onStart(u: String?) {}
      override fun onDone(u: String?) { h.post(done) }
      override fun onError(u: String?) { h.post(done) } })
    tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
  }
  fun listen(lang: String, offline: Boolean, ok: (String) -> Unit, err: () -> Unit) {
    sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(c)
    sr!!.setRecognitionListener(object : RecognitionListener {
      override fun onReadyForSpeech(p: Bundle?) {} override fun onBeginningOfSpeech() {} override fun onRmsChanged(r: Float) {}
      override fun onBufferReceived(b: ByteArray?) {} override fun onEndOfSpeech() {} override fun onEvent(t: Int, b: Bundle?) {}
      override fun onPartialResults(b: Bundle?) {} override fun onError(e: Int) { err() }
      override fun onResults(b: Bundle?) { val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if (t.isNullOrBlank()) err() else ok(t) } })
    sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
      .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang).putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline))
  }
  fun stop() { sr?.destroy(); tts.stop() }
}
